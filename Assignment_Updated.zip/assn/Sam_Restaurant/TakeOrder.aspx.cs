﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
public partial class TakeOrder : System.Web.UI.Page
{
    SqlConnection con;


    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        if (!IsPostBack)
        {
            selectitem();
        }
    }

    public void selectitem()
    {
        using (SqlCommand cmd = new SqlCommand())
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "select ItemId, ItemName from Iem123;";
            SqlDataReader dr = cmd.ExecuteReader();
            selectitem1.DataSource = dr;
            selectitem1.DataTextField = "ItemName";
            selectitem1.DataValueField = "ItemId";
            selectitem1.DataBind();
            selectitem1.Items.Insert(0, "select");
            con.Close();

        }

    }




    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Session["cart"] == null)
        {
            List<item> cart = new List<item>();
            var item = MenuServices.itemList.ToList().Find(x => x.itemId == int.Parse(selectitem1.Text));
            if (item != null)
            {
                item.itemId = 1;
                cart.Add(new item { itemId = 1, itemName = item.itemName, itemPreTime = item.itemPreTime, itemPrice = item.itemPrice * (Convert.ToInt32(txt_quant.Text)) });
                Session["cart"] = cart;
            }

        }
        else
        {

            List<item> cart = (List<item>)Session["cart"];
            var item = MenuServices.itemList.ToList().Find(x => x.itemId == int.Parse(selectitem1.Text));
            if (item != null)
            {
                var maxId = cart.Max(x => x.itemId);

                cart.Add(new item { itemId = maxId + 1, itemName = item.itemName, itemPreTime = item.itemPreTime, itemPrice = item.itemPrice*(Convert.ToInt32(txt_quant.Text)) });
                Session["cart"] = cart;

            }

        }
        LoadCart();
    }

    private void LoadCart()
    {
        GridView1.DataSource = ((List<item>)Session["cart"]);
        GridView1.DataBind();
    }



    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        int index = e.NewEditIndex;
        var itemId = GridView1.Rows[index].Cells[1];
        Response.Write(itemId);
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int index = e.RowIndex;
        var itemId = int.Parse(GridView1.Rows[index].Cells[1].Text);
        //Response.Write(itemId);
        if (Session["cart"] != null)
        {
            List<item> list = (List<item>)Session["cart"];
            var item = list.Find(x => x.itemId == itemId);
            list.Remove(item);
            Session["cart"] = list;
            LoadCart();

        }


    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        GridView1.Enabled = false;
        txt_amount.Visible = true;
        selectitem1.Enabled = false;
        int sum = 0;
        for (int i = 0; i <GridView1.Rows.Count; i++)
        {
            sum += Convert.ToInt32(GridView1.Rows[i].Cells[4].Text);
        }
        Response.Write(txt_amount);
    }

    protected void selectitem1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}