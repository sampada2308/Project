﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["error"] != null)
        {
            Response.Write("<script> alert('Please login first !!') </script>");

            ViewState["nextPage"] = Request.QueryString["page"].ToString();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
        using (SqlCommand cmd = new SqlCommand())
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "select FirstName, Password from Registeration where FirstName=@FirstName and Password=@Password";
            cmd.Parameters.AddWithValue("FirstName", TextBox1.Text);
            cmd.Parameters.AddWithValue("Password", TextBox2.Text);

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["FirstName"] = dr["FirstName"].ToString();
                Session["Password"] = dr["Password"].ToString();
                Label1.Text = "Login Successfull";
                TextBox1.Text = "";
                if (ViewState["nextPage"] == null)
                {
                    Response.Redirect("index.aspx");
                }
                else
                {
                    Response.Redirect(ViewState["nextPage"].ToString());
                }
            }
            else
            {
                Label1.Text = "User name / password not matched !!";

            }
            dr.Close();
            con.Close();
        }
    }



    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
}