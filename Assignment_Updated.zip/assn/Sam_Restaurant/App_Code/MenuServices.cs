﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for MenuServices
/// </summary>
public class MenuServices
{
    public static item[] itemList = new item[5]
            {
        new item(1,"Chicken Stroganoff",30,200),
        new item(2,"Roasted Chicken",30,250),
        new item(3,"Barbecue chicken",20,350),
        new item(4,"Brown stew chicken",25,500),
        new item(5,"Beer can chicken",25,500)
             };
        public void abc(GridView gc)
        {
            gc.DataSource = itemList;
            gc.DataBind();
        }

    }
