﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Submit_btn_Click(object sender, EventArgs e)
    {
        using (ProjectAppContext pc = new ProjectAppContext())
        {
            Bid_Detail bd = new Bid_Detail
            {
                Bid_Id = bid_txt.Text,
                Client_Name = name_txt.Text,
                Project_Duration = Convert.ToInt32(Duration_txt.Text),
                Team_Members = Convert.ToInt32(Team_txt.Text)

            };

            pc.Bid_Details.Add(bd);
            pc.SaveChanges();
            Response.Write("Inserted Successfully");

        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {

        ProjectAppContext pc = new ProjectAppContext();


        var id = pc.Bid_Details.ToList().Find(x => x.Bid_Id == bid_txt.Text);


        id.Client_Name = name_txt.Text;
        id.Project_Duration = Convert.ToInt32(Duration_txt.Text);
        id.Team_Members = Convert.ToInt32(Team_txt.Text);

        pc.SaveChanges();
        Response.Write("Updated Successfully");
    }



    protected void Button1_Click(object sender, EventArgs e)
    {

        ProjectAppContext pc = new ProjectAppContext();

        var id = pc.Bid_Details.ToList().Find(x => x.Bid_Id == bid_txt.Text);
        pc.Bid_Details.Remove(id);
        pc.SaveChanges();
        Response.Write("Deleted");
    }
}
    