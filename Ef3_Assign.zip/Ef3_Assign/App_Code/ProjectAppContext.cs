﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;


    public class ProjectAppContext : DbContext
    {


        public ProjectAppContext() : base("server=MDT1041;uid=sa;pwd=info@123;database=Projects")
        {
        }

   
    public DbSet<Bid_Detail> Bid_Details { get; set; }
    }
