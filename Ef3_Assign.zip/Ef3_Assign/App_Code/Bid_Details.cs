﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;


public class Bid_Detail
{

    [Key]
    [RegularExpression(@"B\d{3}", ErrorMessage = "Enter valid Id")]
    public string Bid_Id { get; set; }

    [RegularExpression(@"[a-zA-Z]{5,}", ErrorMessage = "Enter Valid Name")]
    public string Client_Name { get; set; }

    public enum Domain { Retail, Insurance, Mobility, Medical};

    [Range(1, 100, ErrorMessage = "Enter Valid Duration")]
    public int Project_Duration { get; set; }

    [Range(10, 1000, ErrorMessage = "Atleast 10 members are required")]
    public int Team_Members { get; set; }

  
    
}