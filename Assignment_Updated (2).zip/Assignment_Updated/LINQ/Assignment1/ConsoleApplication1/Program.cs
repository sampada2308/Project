﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ConsoleApplication1
{
    class Program
    {

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
        //static void Main(string[] args)
        //{
        //DataClasses1DataContext dc = new DataClasses1DataContext();

        ////Search All Accidents data

        //var query = from acc in dc.Accident_Claims
        //            select acc;

        //foreach (var item in query)
        //{
        //    Console.WriteLine($" ClaimNumber {item.ClaimNumber} PolicyNum {item.PolicyNumber} VehicleNum {item.VehicleNumber} Owner {item.OwnerName} Acc_Location {item.AccidentLocation} RegistrationLocation {item.PolicyregLoc} InjuredMembers {item.InjuredMembers}");
        //    Console.ReadLine();

        //}

        //// To insert new data
        //Accident_Claim acci = new Accident_Claim()
        //{
        //    PolicyNumber = 101,
        //    VehicleNumber = "MH010145",
        //    OwnerName = "Mohit Sharma",
        //    AccidentLocation = "Mumbai",
        //    PolicyregLoc = "Thane",
        //    InjuredMembers = 4

        //};


        //dc.Accident_Claims.InsertOnSubmit(acci);
        //dc.SubmitChanges();

        //// To delete the data

        //Console.WriteLine("Enter the claim number you want to delete");
        //int ClaimNumber = int.Parse(Console.ReadLine());

        //var accid = dc.Accident_Claims.ToList().Find(x => x.ClaimNumber == ClaimNumber);

        //if (accid != null)
        //{
        //    dc.Accident_Claims.DeleteOnSubmit(accid);
        //    Console.WriteLine("Record Deleted Successfully");
        //    Console.ReadLine();
        //}
        //else
        //{
        //    Console.WriteLine("Clain Number not found");
        //    Console.ReadLine();
        //}

        //// To Update the data

        //Console.WriteLine("Enter the Claim Number You want to Update");
        //int Claim1 = int.Parse(Console.ReadLine());

        //var accident = dc.Accident_Claims.ToList().Find(x => x.ClaimNumber == Claim1);

        //if (accident != null)
        //{
        //    Console.WriteLine("Enter new Owner Name");
        //    string OwnerName = Console.ReadLine();
        //    Console.WriteLine("Enter new Policy Number");
        //    int PolicyNumber = int.Parse(Console.ReadLine());
        //    Console.WriteLine("Enter new Vehicle Number");
        //    string VehicleNumber = Console.ReadLine();
        //    Console.WriteLine("Enter new Accident Location");
        //    string AccidentLocation = Console.ReadLine();
        //    Console.WriteLine("Enter new Policy Registration Location");
        //    string PolicyregLoc = Console.ReadLine();
        //    Console.WriteLine("Enter number of people injured");
        //    float InjuredMembers = float.Parse(Console.ReadLine());

        //    accident.OwnerName = OwnerName;
        //    accident.PolicyNumber = PolicyNumber;
        //    accident.VehicleNumber = VehicleNumber;
        //    accident.AccidentLocation = AccidentLocation;
        //    accident.PolicyregLoc = PolicyregLoc;
        //    accident.InjuredMembers = InjuredMembers;

        //    dc.SubmitChanges();
        //    Console.WriteLine("Record Updated Successfully!");
        //    Console.ReadLine();
        //}
        //else
        //{
        //    Console.WriteLine("Record Not Found!");
        //    Console.ReadLine();
        //}




    }
        }

    

