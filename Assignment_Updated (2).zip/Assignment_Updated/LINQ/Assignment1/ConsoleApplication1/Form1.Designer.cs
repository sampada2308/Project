﻿namespace ConsoleApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.pol_no = new System.Windows.Forms.Label();
            this.veh_text = new System.Windows.Forms.Label();
            this.own_text = new System.Windows.Forms.Label();
            this.acc_text = new System.Windows.Forms.Label();
            this.polreg_text = new System.Windows.Forms.Label();
            this.injumem_text = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Claim Number";
            // 
            // pol_no
            // 
            this.pol_no.AutoSize = true;
            this.pol_no.Location = new System.Drawing.Point(82, 104);
            this.pol_no.Name = "pol_no";
            this.pol_no.Size = new System.Drawing.Size(75, 13);
            this.pol_no.TabIndex = 1;
            this.pol_no.Text = "Policy Number";
            // 
            // veh_text
            // 
            this.veh_text.AutoSize = true;
            this.veh_text.Location = new System.Drawing.Point(82, 138);
            this.veh_text.Name = "veh_text";
            this.veh_text.Size = new System.Drawing.Size(82, 13);
            this.veh_text.TabIndex = 2;
            this.veh_text.Text = "Vehicle Number";
            // 
            // own_text
            // 
            this.own_text.AutoSize = true;
            this.own_text.Location = new System.Drawing.Point(82, 183);
            this.own_text.Name = "own_text";
            this.own_text.Size = new System.Drawing.Size(69, 13);
            this.own_text.TabIndex = 3;
            this.own_text.Text = "Owner Name";
            // 
            // acc_text
            // 
            this.acc_text.AutoSize = true;
            this.acc_text.Location = new System.Drawing.Point(82, 222);
            this.acc_text.Name = "acc_text";
            this.acc_text.Size = new System.Drawing.Size(93, 13);
            this.acc_text.TabIndex = 4;
            this.acc_text.Text = "Accident Location";
            // 
            // polreg_text
            // 
            this.polreg_text.AutoSize = true;
            this.polreg_text.Location = new System.Drawing.Point(82, 263);
            this.polreg_text.Name = "polreg_text";
            this.polreg_text.Size = new System.Drawing.Size(138, 13);
            this.polreg_text.TabIndex = 5;
            this.polreg_text.Text = "Policy Registration Location";
            // 
            // injumem_text
            // 
            this.injumem_text.AutoSize = true;
            this.injumem_text.Location = new System.Drawing.Point(82, 307);
            this.injumem_text.Name = "injumem_text";
            this.injumem_text.Size = new System.Drawing.Size(85, 13);
            this.injumem_text.TabIndex = 6;
            this.injumem_text.Text = "Injured Members";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(320, 61);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(320, 97);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(320, 131);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 9;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(320, 176);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 10;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(320, 219);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 11;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(320, 263);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 12;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(320, 307);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 13;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(712, 61);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 14;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(712, 128);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 15;
            this.button3.Text = "Insert";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(712, 183);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 16;
            this.button4.Text = "Update";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(712, 241);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 17;
            this.button5.Text = "Delete";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(712, 304);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 18;
            this.button6.Text = "Save File";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(913, 463);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.injumem_text);
            this.Controls.Add(this.polreg_text);
            this.Controls.Add(this.acc_text);
            this.Controls.Add(this.own_text);
            this.Controls.Add(this.veh_text);
            this.Controls.Add(this.pol_no);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label claim;
        private System.Windows.Forms.Label policy;
        private System.Windows.Forms.Label veh_num;
        private System.Windows.Forms.Label own_name;
        private System.Windows.Forms.Label acc_loc;
        private System.Windows.Forms.Label prl;
        private System.Windows.Forms.Label injured_mem;
        private System.Windows.Forms.TextBox claim_text;
        private System.Windows.Forms.TextBox policy_text;
        private System.Windows.Forms.TextBox vehicle_text;
        private System.Windows.Forms.TextBox owner_text;
        private System.Windows.Forms.TextBox accloc_text;
        private System.Windows.Forms.TextBox prl_text;
        private System.Windows.Forms.TextBox injured_text;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label pol_no;
        private System.Windows.Forms.Label veh_text;
        private System.Windows.Forms.Label own_text;
        private System.Windows.Forms.Label acc_text;
        private System.Windows.Forms.Label polreg_text;
        private System.Windows.Forms.Label injumem_text;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
    }
}