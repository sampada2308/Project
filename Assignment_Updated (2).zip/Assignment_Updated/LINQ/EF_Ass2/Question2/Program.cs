﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Question2
{
    class Program
    {
        static void Main(string[] args)
        {

            //Band : Appearances : Event
            //var db = new CarsEntities10();

            //Band b = new Band { NAME = "Sam", age = "22" };
            //Band b1 = new Band { NAME = "Vrush", age = "20" };
            //Appearance a = new Appearance { ap_name = "Sam" };

            ////  Event1 e = new Event1 { Event_name = "Rahul" };




            //b.Appearances.Add(a);
            //b1.Appearances.Add(a);


            //db.Bands.Add(b);
            //db.Appearances.Add(a);

            //db.SaveChanges();
            //Console.WriteLine("Insertion Done !!");

            //Movie: Cast: Actor
            //var db = new CarsEntities12();

            //Movie m = new Movie { NAME = "Sam", age = "22" };
            //Movie m1 = new Movie { NAME = "Sam",age="22" };

            //cast1 e = new cast1 { cast_name = "Rahul" };



            //m.cast1.Add(e);
            //m1.cast1.Add(e);

            //db.Movies.Add(m);
            //db.Movies.Add(m1);

            //db.SaveChanges();
            //Console.WriteLine("Insertion Done !!");

            //Room : Booking : Guest
            //var db = new CarsEntities13();

            //Room r = new Room { NAME = "Sam", age = "22" };
            //Room r1 = new Room { NAME = "SURAJ", age = "23" };
            //Booking b = new Booking { b_name = "Sam" };





            //r.Bookings.Add(b);
            //r1.Bookings.Add(b);

            //db.Rooms.Add(r);
            //db.Rooms.Add(r1);

            //db.SaveChanges();
            //Console.WriteLine("Insertion Done !!");


            //Student :Enroll:Course
            //var db = new CarsEntities14();

            //Student11 s = new Student11 { NAME = "Sam", Dept = "22" };
            //Student11 s1 = new Student11 { NAME = "Sampada", Dept = "21" };
            //Enroll n = new Enroll { E_name = "Sam" };





            //s.Enrolls.Add(n);
            //s1.Enrolls.Add(n);

            //db.Student11.Add(s);
            //db.Student11.Add(s1);

            //db.SaveChanges();

            //Console.WriteLine("Insertion Done !!");


            //Employee:Assign:Project
            var db = new CarsEntities9();



            Assign a1 = new Assign { A_name = "vrsh" };
            Assign a2 = new Assign { A_name = "aish" };

            Employee1 e = new Employee1 { NAME = "Sam", dEPT = "ITY" };




            a1.Employee1.Add(e);
            a2.Employee1.Add(e);

            db.Assigns.Add(a1);
            db.Assigns.Add(a2);

            db.SaveChanges();
            Console.WriteLine("Insertion Done !!");





        }
    }
}
