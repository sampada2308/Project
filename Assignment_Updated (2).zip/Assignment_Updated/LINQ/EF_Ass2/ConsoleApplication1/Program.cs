﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            //Employee :Computer
            var db = new CarsEntities12();


            Employeee emp = new Employeee { Ename = "SAMPADA" };
            Computerr cmp = new Computerr
            {
                CLoc = "Mum",
                Employeee = emp


            };
            db.Computerrs.Add(cmp);
            db.SaveChanges();
            Console.WriteLine("Insertion Done !!");


            //House Number:Parking Location
            //var db = new CarsEntities13();


            //House_Number hn = new House_Number { Hname = "Shree" };
            //Parking_Location pl = new Parking_Location
            //{
            //    PLLoc = "Terrace",
            //    House_Number = hn

            //};
            //db.Parking_Location.Add(pl);
            //db.SaveChanges();
            //Console.WriteLine("Insertion Done !!");


            //Conference Room:Sitting Location
            //var db = new CarsEntities14();


            //Conference cn = new Conference { Cname = "mum" };
            //Sitting sl = new Sitting
            //{
            //    SLLoc = "seat12",
            //    Conference=cn


            //};
            //db.Sittings.Add(sl);
            //db.SaveChanges();
            //Console.WriteLine("Insertion Done !!");

            //Person :Passport
            //var db = new CarsEntities15();


            //Personn p = new Personn { Pname = "Sam" };
            //Passportt sl = new Passportt
            //{
            //    PPLoc = "London",
            //    Personn = p


            //};
            //db.Passportts.Add(sl);
            //db.SaveChanges();
            //Console.WriteLine("Insertion Done !!");


            //Department:Head
            //var db = new CarsEntities16();
            ////  db.Database.Log = Console.WriteLine;

            //Deptt d = new Deptt { Dname = "IT" };
            //Headd h = new Headd
            //{
            //    HHName = "Sam",
            //    Deptt = d



            //};
            //db.Headds.Add(h);
            //db.SaveChanges();
            //Console.WriteLine("Insertion Done !!");
        }
    }
}
