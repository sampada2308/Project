﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowCorporateOffer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["FirstName"] == null)
        {
            Response.Redirect("Login.aspx?error=403&page=ShowCorporateOffer.aspx");
        }
        if (Request.QueryString["error"] != null)
        {
            Response.Write("<script> alert('Please login first !!') </script>");

            ViewState["nextPage"] = Request.QueryString["page"].ToString();
        }
    }
}