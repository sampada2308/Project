﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Registration_Page : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    }



    protected void ImageButton1_Click1(object sender, ImageClickEventArgs e)
    {
        using (SqlCommand cmd = new SqlCommand())
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "insert into Registeration values( @id,@firstname,@lastname,@phneno,@emailid,@paswrd,@reenterpwd);";
            cmd.Parameters.AddWithValue("id", TextBox7.Text);
            cmd.Parameters.AddWithValue("firstname", TextBox1.Text);
            cmd.Parameters.AddWithValue("lastname", TextBox2.Text);
            cmd.Parameters.AddWithValue("phneno", TextBox3.Text);
            cmd.Parameters.AddWithValue("emailid", TextBox4.Text);
            cmd.Parameters.AddWithValue("paswrd", TextBox5.Text);
            cmd.Parameters.AddWithValue("reenterpwd", TextBox6.Text);
            cmd.ExecuteNonQuery();
            Response.Redirect("Login.aspx");
            con.Close();



        }
    }
}




