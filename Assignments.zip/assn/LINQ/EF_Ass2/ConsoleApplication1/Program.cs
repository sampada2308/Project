﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            //Employee :Computer
            var db = new CarsEntities();


            Employee emp = new Employee { Name = "Sam", Dept = "IT" };
            Computer cmp = new Computer
            {
                Model = "X00",
                Employee = emp

            };
            db.Computers.Add(cmp);
            db.SaveChanges();
            Console.WriteLine("Insertion Done !!");


            //House Number:Parking Location
            // var db = new CarsEntities1();


            //HouseNo hn = new HouseNo { Name = "Sam", Location = "Mumbai" };
            //Parking_Loc pl = new Parking_Loc
            //{
            //    Number = 1001,
            //    HouseNo = hn

            //};
            //db.Parking_Loc.Add(pl);
            //db.SaveChanges();
            //Console.WriteLine("Insertion Done !!");


            //Conference Room:Sitting Location
            //var db = new CarsEntities2();


            //ConRoom cn = new ConRoom { NoOfRooms = 5};
            //Sitting_Loc sl = new Sitting_Loc
            //{
            //    Number = 100


            //};
            //db.Sitting_Loc.Add(sl);
            //db.SaveChanges();
            //Console.WriteLine("Insertion Done !!");

            //Person :Passport
            //var db = new CarsEntities3();


            //Person p = new Person { Name = "Sam", Age = 23 };
            //Passport sl = new Passport
            //{
            //    Number = 100


            //};
            //db.Passports.Add(sl);
            //db.SaveChanges();
            //Console.WriteLine("Insertion Done !!");


            //Department:Head
            //var db = new CarsEntities4();
            ////  db.Database.Log = Console.WriteLine;

            //Department d = new Department { Name = "IT" };
            //Head1 h = new Head1
            //{
            //    Name = "Sam"


            //};
            //db.Head1.Add(h);
            //db.SaveChanges();
            //Console.WriteLine("Insertion Done !!");
        }
    }
}
