﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleApplication1
{
    public partial class Form1 : Form
    {
        DataClasses1DataContext dc = new DataClasses1DataContext();
        public Form1()
        {
            InitializeComponent();
        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    DataClasses1DataContext dc = new DataClasses1DataContext();
        //    Accident_Claim acci = new Accident_Claim()
        //    {
        //        PolicyNumber = 101,
        //        VehicleNumber = "MH010145",
        //        OwnerName = "Mohit Sharma",
        //        AccidentLocation = "Mumbai",
        //        PolicyregLoc = "Thane",
        //        InjuredMembers = 4

        //    };


        //    dc.Accident_Claims.InsertOnSubmit(acci);
        //    dc.SubmitChanges();

        //}

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            button3.Visible = true;
            button4.Visible = true;

            Accident_Claim acc = new Accident_Claim();

            var value = dc.Accident_Claims.Where(x => x.ClaimNumber == Convert.ToInt32(claim.Text)).First();

            if (value != null)
            {

                pol_no.Text = value.PolicyNumber;
                veh_text.Text = value.VehicleNumber;
                own_text.Text = value.OwnerName;
                acc_text.Text = value.AccidentLocation;
                polreg_text.Text = value.PolicyregLoc;
                injumem_text.Text = value.InjuredMembers;

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {

            Accident_Claim acc = new Accident_Claim();
            acc.PolicyNumber = pol_no.Text;
            acc.VehicleNumber = veh_text.Text;
            acc.OwnerName = own_text.Text;
            acc.AccidentLocation = acc_text.Text;
            acc.PolicyregLoc = polreg_text.Text;
            acc.InjuredMembers = injumem_text.Text;

            dc.Accident_Claims.InsertOnSubmit(acc);
            dc.SubmitChanges();

            Console.WriteLine("Data Inserted");
            claim.Text = Convert.ToString(acc.ClaimNumber);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Accident_Claim acc = new Accident_Claim();

            var value = dc.Accident_Claims.Where(x => x.ClaimNumber == Convert.ToInt32(claim.Text)).First();




            if (value != null)
            {
                value.PolicyNumber =pol_no.Text;
                value.VehicleNumber = veh_text.Text;
                value.OwnerName = own_text.Text;
                value.AccidentLocation = acc_text.Text;
                value.PolicyregLoc = polreg_text.Text;
                value.InjuredMembers = injumem_text.Text;


                dc.SubmitChanges();

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            var acc = dc.Accident_Claims.ToList().Where(x => x.ClaimNumber == Convert.ToInt32(claim.Text));

            if (acc != null)
            {
                dc.Accident_Claims.DeleteAllOnSubmit(acc);
                dc.SubmitChanges();
                Console.WriteLine("Record Deleted Successfully");
            }
            else
            {
                Console.WriteLine("Record not found!");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var acc = dc.Accident_Claims.ToList().Where(x => x.ClaimNumber == Convert.ToInt32(claim.Text));

            using (TextWriter tw = new StreamWriter("C:/Users/sampada.mirashi   / Documents / LINQ / Assignment1.txt")) ;

            {
                foreach (var item in acc)
                {
                    Console.WriteLine(string.Format("PolicyNo:{0} -    VechicleNo: {1}   OwnerName :{2}      PolicyRegLocation:{3}       AccidentLocation:{4}     NoMemberInjured:{5}", item.PolicyNumber, item.VehicleNumber, item.OwnerName, item.PolicyregLoc, item.AccidentLocation, item.InjuredMembers));

                }
            }
        }
    }
}
